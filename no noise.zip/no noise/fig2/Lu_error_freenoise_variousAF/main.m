clc;clear
close all;
global lambda1 lambda2 a b c d alpha beta t_set Delta i Ut Tt

f_times=20000; %指的是ode里面精确的迭代次数，不知道到可以设大些，确保大于ode迭代的次数
Ut=zeros(f_times,3);
Tt=zeros(f_times,1);
alpha=2;
beta=2;
t_set=0.1;
lambda1=0.5; lambda2=0.5; 
a=36;b=3;c=20;  %%%混沌系统参数
d=0;

tspan=0:0.002:0.1; 
%options=odeset('Mass', @matrixM, 'MStateDep', 'none');
i=1;
z0=[0;0.1;0.3;1;1;5;0;0;0];
options = odeset('RelTol',1e-3,'AbsTol',1e-5);

%%%背景设置为白色
set(0,'defaultfigurecolor','w')

[t,x]=ode45(@slave_chaotic_system_TAF, tspan, z0,options);
[m,n]=size(x);
Err=zeros(m,3);
Err(:,1)=x(:,4)-x(:,1);
Err(:,2)=x(:,5)-x(:,2);
Err(:,3)=x(:,6)-x(:,3);
nerr=norm(Err);

nerr=zeros(m,1);
for j=1:length(t)
    nerr(j)=norm(Err(j,:));
end
figure(5);
plot(t,nerr,'c-.','linewidth',2);hold on;

[t1,x]=ode45(@slave_chaotic_system_SBPAF, tspan, z0,options);
[m1,n]=size(x);
Err1=zeros(m1,3);
Err1(:,1)=x(:,4)-x(:,1);
Err1(:,2)=x(:,5)-x(:,2);
Err1(:,3)=x(:,6)-x(:,3);

nerr1=zeros(m1,1);
for j=1:length(t1)
    nerr1(j)=norm(Err1(j,:));
end
figure(5);
plot(t1,nerr1,'m--','linewidth',2);hold on;

[tf,x]=ode45(@slave_chaotic_system_FXTAF, tspan, z0,options);
[m1,n]=size(x);
Errf=zeros(m1,3);
Errf(:,1)=x(:,4)-x(:,1);
Errf(:,2)=x(:,5)-x(:,2);
Errf(:,3)=x(:,6)-x(:,3);

nerr1=zeros(m1,1);
for j=1:length(t1)
    nerrf(j)=norm(Errf(j,:));
end
figure(5);
plot(tf,nerrf,'g','linewidth',2);hold on;

[t2,x]=ode45(@slave_chaotic_system_PDTAF, tspan, z0,options);
[m2,n]=size(x);
Err2=zeros(m2,3);
Err2(:,1)=x(:,4)-x(:,1);
Err2(:,2)=x(:,5)-x(:,2);
Err2(:,3)=x(:,6)-x(:,3);

nerr2=zeros(m2,1);
for j=1:length(t2)
    nerr2(j)=norm(Err2(j,:));
end
figure(5);
plot(t2,nerr2,'b:','linewidth',2);hold on;
legend('boxoff');
%%%%%全局设置
set(gca,'FontSize',12,'Fontname', 'Times New Roman');
%%%一般常用右上角northeast
legend({'TAF','SBPAF','FXTAF','PDTAF'},'Fontname', 'Times New Roman','FontSize',14,'Location','northeast');
%放大坐标轴至充满图形
set(gca,'looseInset',[0 0 0 0]);
%
text(3.41,0.3,'t(s)','Fontname', 'Times New Roman','FontSize',12)
text(0.7,4,'error','Fontname', 'Times New Roman','FontSize',12)
%%%%矢量输出
fig5 = figure(5); %对应的figure+编号
fig5.Renderer = 'Painters'; 


