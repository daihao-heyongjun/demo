%nonlinear Predefined time activation function
function y =VP_PDTAF1(s,t)
%AFMSIGNBIPOWER �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
global t_set beta lambda2
    p=2;q=0.5;
    k1=0.5;k2=0.5;k3=0;k4=0;
    theta=(1-q)/(p-q);
    y=(2*((k2/k1)^(theta)*pi*csc(theta*pi)/(2*beta*exp(lambda2)*k2*(p-q)/2))/t_set)*(k1*abs(s).^p+k2*abs(s).^q).*sign(s) + k3*s+k4*sign(s);
end

