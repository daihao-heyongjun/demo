function y=AFsbp(x,q)
    q=0.5;
    y=(0.5*abs(x).^q+0.5*abs(x).^(1/q)).*sign(x);
end