function m_sys = master_chaotic_system(t,x)
%Delta=(3+sin(5*1*pi*t-2)+sin(10*1*pi*t+5)+sin(15*1*pi*t-7)+sin(25*1*pi*t+9));%混合正弦谐波噪声
global a b c Delta
m_sys=zeros(3,1);
m_sys(1)=a*(x(2)-x(1))+Delta;
m_sys(2)=-x(1)*x(3)+c*x(2)+Delta;
m_sys(3)=x(1)*x(2)-b*x(3)+Delta;

t1=t