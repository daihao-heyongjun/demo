clc;clear
close all;
global lambda1 lambda2 a b c d alpha beta Delta i Ut Tt

f_times=20000; %指的是ode里面精确的迭代次数，不知道到可以设大些，确保大于ode迭代的次数
Ut=zeros(f_times,3);
Tt=zeros(f_times,1);
alpha=2;
beta=2;
lambda1=0.5; lambda2=0.5; 
a=36;b=3;c=20;  %%%混沌系统参数
d=0;
%Delta=(3+sin(5*1*pi*t-2)+sin(10*1*pi*t+5)+sin(15*1*pi*t-7)+sin(25*1*pi*t+9));%混合正弦谐波噪声
Delta=0;%%%%无噪声

tspan=0:0.002:10; 
%options=odeset('Mass', @matrixM, 'MStateDep', 'none');
i=1;
z0=[0;0.1;0.3;1;1;5;0;0;0];
options = odeset('RelTol',1e-3,'AbsTol',1e-5);

[t,x]=ode45(@slave_chaotic_system_FXTAF, tspan, z0,options);
% figure(1);
% plot(x(:,1),x(:,2),'r--','linewidth',1.5);hold on;
% figure(1);
% plot(x(:,4),x(:,5),'b','linewidth',0.7);
% legend({'Master System','Stave System'},'FontSize',10);
% legend('boxoff');
% xlabel('x1');
% ylabel('x2');
% 
% 
% figure(2);
% plot(x(:,1),x(:,3),'r--','linewidth',1.5);hold on;
% figure(2);
% plot(x(:,4),x(:,6),'b','linewidth',0.7);
% legend({'Master System','Stave System'},'FontSize',10);
% legend('boxoff');
% xlabel('x1');
% ylabel('x3');
% 
% figure(3);
% plot(x(:,2),x(:,3),'r--','linewidth',1.5);hold on;
% figure(3);
% plot(x(:,5),x(:,6),'b','linewidth',0.7);
% legend({'Master System','Stave System'},'FontSize',10);
% legend('boxoff');
% xlabel('x2');
% ylabel('x3');

figure(4)
plot3(x(1:3:end,1),x(1:3:end,3),x(1:3:end,2),'r--','linewidth',1.2);hold on
plot3(x(1:3:end,4),x(1:3:end,6),x(1:3:end,5),'b','linewidth',0.7);
legend('boxoff');
%%%%%全局设置
set(gca,'FontSize',14,'Fontname', 'Times New Roman');
%%%LaTeX表示
xlabel({'$x_{1}$'},'Interpreter','latex','FontSize',20)
ylabel({'$x_{3}$'},'Interpreter','latex','FontSize',20)
zlabel({'$x_{2}$'},'Interpreter','latex','FontSize',20)
grid on;
%%%输出矢量图
fig4 = figure(4); %对应的figure+编号
fig4.Renderer = 'Painters'; 
% 完全去除间隔, 可能会去除掉边界的一些信息, 请检查后使用
set(gca,'LooseInset', get(gca,'TightInset'))
% 宽度方向空白区域0.03， 高度方向空白区域0.05
set(gca,'looseInset',[0 0 0.03 0.05]);
%%%一般常用右上角northeast
legend({'Master System','Stave System'},'Fontname', 'Times New Roman','FontSize',16,'Location','southeast');
%%放大坐标轴至充满图形
set(gca,'looseInset',[0 0 0 0]);
%%背景设置为白色，可加可不加
set(gcf,'defaultfigurecolor','w')

[m,n]=size(x);
Err=zeros(m,3);
Err(:,1)=x(:,4)-x(:,1);
Err(:,2)=x(:,5)-x(:,2);
Err(:,3)=x(:,6)-x(:,3);

% figure(5);
% plot(t,Err(:,1),'c','linewidth',2);hold on;
% figure(5);
% plot(t,Err(:,2),'m-.','linewidth',2);hold on;
% figure(5);
% plot(t,Err(:,3),'b:','linewidth',2);hold on;
% legend({'error1','error2','error3'},'FontSize',12);
% legend('boxoff');
% %axis([0 0.4 -1 5])

% figure(6);
% %mm=length(Ut);
% % Ut=Ut(1:50:end,:);
% % Tt=Tt(1:50:end,:);
% plot(Tt,Ut(:,1),'c','linewidth',2);hold on;
% plot(Tt,Ut(:,2),'m-.','linewidth',2);hold on;
% plot(Tt,Ut(:,3),'b:','linewidth',2);hold on;
% legend({'u001','u002','u003'},'FontSize',12);
% legend('boxoff');
% xlabel('time(s)');ylabel('Control input');

