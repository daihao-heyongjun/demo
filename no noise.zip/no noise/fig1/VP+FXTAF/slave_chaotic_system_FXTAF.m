function output = slave_chaotic_system_FXTAF(t,z,i)
global lambda1 lambda2 a b c d alpha beta Delta i Ut Tt
%Delta=(3+sin(5*1*pi*t-2)+sin(10*1*pi*t+5)+sin(15*1*pi*t-7)+sin(25*1*pi*t+9));%混合正弦谐波噪声
Delta=0;%%%%噪声
x=z(1:3); %%主系统状态
y=z(4:6); %%从系统状态
Intl_AF_e=z(7:9); %%积分后
err=y-x;

AF_e=alpha*exp(lambda1*acot(t)+lambda2)*NPTAF(err);

s=err+Intl_AF_e;
%%%%

%%%趋近律设计r_law即reaching_law

r_law=-beta*exp(lambda1*acot(t)+lambda2)*NPTAF(s)-d*sign(s); 

%%控制器
ut=zeros(3,1);
ut(1)=-alpha*exp(lambda1*acot(t)+lambda2)*NPTAF(err(1))+r_law(1)-(a*(y(2)-y(1))-a*(x(2)-x(1)));
ut(2)=-alpha*exp(lambda1*acot(t)+lambda2)*NPTAF(err(2))+r_law(2)-(-y(1)*y(3)+c*y(2)-(-x(1)*x(3)+c*x(2)));
ut(3)=-alpha*exp(lambda1*acot(t)+lambda2)*NPTAF(err(3))+r_law(3)-(y(1)*y(2)-b*y(3)-(x(1)*x(2)-b*x(3)));

% %%保存控制器和对应的时间点
% Ut(i,:)=ut';
% Tt(i)=t;
% i=i+1;

%%被控系统
s_sys=zeros(3,1);
s_sys(1)=a*(y(2)-y(1))+ut(1);
s_sys(2)=-y(1)*y(3)+c*y(2)+ut(2);
s_sys(3)=y(1)*y(2)-b*y(3)+ut(3);

m_sys=master_chaotic_system(t,z);
output=[m_sys;s_sys;AF_e];

t2=t
